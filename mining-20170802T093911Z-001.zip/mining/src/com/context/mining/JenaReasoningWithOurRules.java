package com.context.mining;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.management.Query;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jena.iri.impl.Main;
import org.apache.jena.query.QueryExecution;
import org.apache.jena.query.QueryExecutionFactory;
import org.apache.jena.query.QueryFactory;
import org.apache.jena.query.QuerySolution;
import org.apache.jena.query.ResultSetFormatter;
import org.apache.jena.rdf.model.InfModel;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.rdf.model.StmtIterator;
import org.apache.jena.reasoner.Reasoner;
import org.apache.jena.reasoner.ReasonerRegistry;
import org.apache.jena.reasoner.rulesys.GenericRuleReasoner;
import org.apache.jena.reasoner.rulesys.Rule;
import org.apache.jena.util.FileManager;

public class JenaReasoningWithOurRules {
	
	public ArrayList<String> createModel(String[] symptom, HttpServletRequest request, HttpServletResponse response) throws IOException{
		
		//System.out.println(symptom);
	
		Model model = ModelFactory.createDefaultModel();
		model.read( "finaldataset.rdf" );
		
		Reasoner transReasoner = ReasonerRegistry.getTransitiveReasoner();//inbuilt reasoner
		
		InfModel infModel = ModelFactory.createInfModel( transReasoner, model );
				
		String fileName = "inter.n3";
		FileWriter out = new FileWriter( fileName );
		try {
			model.write(out, "N-TRIPLES");
		   }
		finally {
		   try {
		       out.close();
		   }
		   catch (IOException closeException) {
		       // ignore
		   }
		}
		System.out.println();
		ArrayList<String> s = sparkTest(symptom, response);
		//StmtIterator it1 = infModel.listStatements();
		
	
	return s;
}
public static ArrayList<String> sparkTest(String[] symptom,HttpServletResponse response) throws IOException{
	String xys;
	PrintWriter out = response.getWriter();
	
	String nsPRE = "http://www.semanticweb.org/vinutha/ontologies/2017/3/untitled-ontology-16#";
	String rdfPRE = "<http://www.w3.org/1999/02/22-rdf-syntax-ns#>";
	FileManager.get().addLocatorClassLoader(Main.class.getClassLoader());
	Model model2 = FileManager.get().loadModel("inter.n3");
	
/*	String querystring = "SELECT * WHERE { " + "?sub ?pre ?obj ."+"}";
			
	  org.apache.jena.query.Query query = QueryFactory.create(querystring);
	  QueryExecution qexec = QueryExecutionFactory.create(query, model2);
	
	try{
		org.apache.jena.query.ResultSet results1 = qexec.execSelect();
		/*while(results.hasNext()){

			 QuerySolution binding = results.nextSolution();                     
			 System.out.println(binding); 
			}*/
			
			/*while(results1.hasNext()){

				 QuerySolution binding = results1.nextSolution();                     
				 System.out.println(binding.get("sub"));
				 out.println(binding.get("sub"));
				 }*/
			
			//System.out.println("\n\n\n\n\n\n\n\n\n");
			
		//ResultSetFormatter.out(System.out, results1, query);
		// xys = ResultSetFormatter.asText(results1);
		 
/*	}
	finally{
		qexec.close();
	}

    
	*/	
	for(int i=0;i<symptom.length;i++){
		symptom[i]=nsPRE+symptom[i];
		//System.out.println(symptom[i]);
	}
	//int temp=symptom.length;
	String x="?sub ?pre <";
	for(int i=0;i<symptom.length;i++){
		
		x=x+symptom[i]+">";
		if(i<symptom.length-1){
			x+=". ?sub ?pre <";
			
		}
		
			
		
	}
	//x+=".";
	//System.out.println(x);
	// code to query only the required set from the inferred .rdf file
	String querystring2 = 		"SELECT ?sub  WHERE { " + x +"}";
	
	
	org.apache.jena.query.Query query2 = QueryFactory.create(querystring2);
	QueryExecution qexec2 = QueryExecutionFactory.create(query2, model2);
	 
	ArrayList<String> list=new ArrayList<String>();
	
	try{
		org.apache.jena.query.ResultSet results2 = qexec2.execSelect();
		//out.println("\n\n\n\n\n\n\n");
		//ResultSetFormatter.out(System.out, results, query2);
		int i=0;
		
		while(results2.hasNext()){

			 QuerySolution binding = results2.nextSolution();                     
			 System.out.println(binding.get("sub").toString().replace(nsPRE, ""));
			// System.out.println(binding.get("pre").toString().replace(nsPRE, ""));
			 //System.out.println(symptom[i].replace(nsPRE, ""));
			 
				
			// out.println(binding.get("sub").toString().replace(nsPRE, ""));
			 list.add(binding.get("sub").toString().replace(nsPRE, "").toString());
			// out.println(binding.get("pre").toString().replace(nsPRE, ""));
			// out.println(symptom[i].replace(nsPRE, ""));
			 i++;
			 }
		
		  /*xys = ResultSetFormatter.asText(results2);
		System.out.println(xys);*/
	
	}
	finally{
		qexec2.close();
	}
	return list;
}
}

