package com.context.mining;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jena.query.QuerySolution;

/**
 * Servlet implementation class Mining
 */
@WebServlet("/Mining")
public class Mining extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Mining() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		JenaReasoningWithOurRules jObj = new JenaReasoningWithOurRules();
		PrintWriter out = response.getWriter();
		
		
		String select = request.getParameter("myData"); 
		//System.out.println(select);
		String[] selectArr = select.split(",");
		
		
		ArrayList<String> str = jObj.createModel(selectArr, request, response);
		
		/*while(resultset.hasNext()){

			 QuerySolution binding = resultset.nextSolution();                     
			 System.out.println(binding);
			 out.println(binding);
			 }*/
		
		/* out.print("<script type='text/javascript'>"+
		 "document.getElementById('result').innerHTML= "+ str +";"
		 + "</script>");  */
		
			request.setAttribute("utilOutput", str);
		        RequestDispatcher rd=request.getRequestDispatcher("/results.jsp");  
		        rd.forward(request, response); 
		        
		
		//out.print(str);
		
	}

}
